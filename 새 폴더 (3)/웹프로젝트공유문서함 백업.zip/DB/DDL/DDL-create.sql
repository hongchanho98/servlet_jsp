﻿-- DDL - create

--================ [ 1단계 ] =============================

-- 1. 회원테이블
create table tblUser (

 userSeq number primary key,             -- 회원번호(PK)
 userName varchar2(20) not null,          -- 회원이름
 userTel varchar2(15) not null,             -- 전화번호
 userId varchar2(50) not null,              -- 회원 아이디
 userPw varchar2(50) not null,             -- 비밀번호
 userBirth date not null ,                  -- 생년월일
 userEmail varchar2(50) not null,          -- 이메일
 userLevel number not null ,               -- 등급
 userPoint number not null,                -- 포인트
 userGenre varchar2(50) , 	               -- 선호장르
 userTheater varchar2(50), 	              -- 선호극장
 userQuestion number, 	                  -- 질문
 userAnswer varchar2(100) ,               -- 답변
 userImage varchar2(100) ,                 -- 프로필사진
 userLv number                              -- 레벨
 

);

-- 1. 회원 시퀀스
create sequence userSeq;

--=====================================================

-- 2. 비회원테이블
create table tblNonUser (
    nonuserSeq number,            -- 비회원번호(PK)
    nonuserName varchar2(20),    -- 이름
    nonuserBirth date,             -- 생년월일
    nonuserPw varchar2(20),       -- 비밀번호
    nonuserTel varchar2(15)       -- 전화번호
);

-- 2. 비회원시퀀스
create sequence nonuserSeq;

--=====================================================
-- 3. 쿠폰테이블
create table tblCoupon (
    
    couponSeq number primary key,            -- 쿠폰 번호, PK
    couponType varchar2(50) not null,          -- 쿠폰 분류
    couponName varchar2(50) not null,         -- 쿠폰 이름
    couponContent varchar2(2000) not null,    -- 쿠폰 내용
    couponExpireDate date not null             -- 쿠폰 유효 기간

);

-- 3. 쿠폰 시퀀스
create sequence couponSeq;

--=====================================================
-- 4. 이벤트&혜택 테이블
create table tblEvent (

 eventSeq number primary key,                 -- 이벤트번호, PK
 eventTitle varchar2(100) not null,              -- 제목
 eventThumbnail varchar2(100) not null,         -- 썸네일
 eventPoster varchar2(100) not null,            -- 포스터
 eventType varchar2(50) not null,               -- 분류
 eventStart date not null,                       -- 시작일
 eventEnd date not null,                         -- 종료일
 eventRegdate date not null,                    -- 등록일

);

-- 4. 이벤트&혜택 시퀀스
create sequence eventSeq;
--=====================================================

-- 5. 영화 테이블
create table tblMovie(
    
    movieSeq number primary key,            -- 영화번호(PK)
    movieKorName varchar2(50) not null,     -- 영화이름(한글)
    movieEngName varchar2(50) not null,     -- 영화이름(영문)
    movieGenre varchar2(50) not null,         -- 장르
    movieOpen date not null,                   -- 개봉일
    movieDirector varchar2(30) not null,      -- 감독
    movieActor varchar2(100)   not null,      -- 주연배우
    movieTime number not null,                -- 러닝타임
    movieCountry varchar2(50) not null,       -- 국가
    movieCompany varchar2(50) not null,      -- 배급사
    movieFormat varchar2(20)  default '2D',  -- 영화상영포맷
    movieAge number not null,                 -- 상영등급
    moviePoster varchar2(100)                  -- 포스터


);

-- 5. 영화 시퀀스
create sequence movieSeq;

--=====================================================

-- 6. 극장 테이블
create table tblTheater (

 theaterSeq number primary key,           -- 극장번호(PK)
 theaterName varchar2(50) not null,        -- 극장이름
 theaterArea varchar2(50)  not null,        -- 지역
 theaterTel varchar2(15)  not null,          -- 전화번호
 theaterAddress varchar2(100)  not null,    -- 주소
 theaterRoomCount number  not null,       -- 상영관수
 theaterInfo varchar2(1000)  not null       -- 극장안내 

);

-- 6. 극장 시퀀스
create sequence theaterSeq;

--=====================================================
-- 7. 자주 묻는 질문 테이블
create table tblQuestion(

  questionSeq number primary key,      -- 게시글번호(PK)
  questionType varchar2(50) not null,    -- 글분류
  questionTitle varchar2(100) not null,   -- 글제목
  questionContent varchar2(2000) not null  -- 글내용

);

-- 7. 자주 묻는 질문 시퀀스
create sequence questionSeq;

--=======================================================

-- 8. 공지사항 테이블
create table tblNotice(

    noticeSeq number,                 -- 게시글 번호
    noticeTime varchar2(100),         -- 글제목
    noticeContent varchar2(2000),   -- 글내용
    noticeDate date                   -- 등록일
);


-- 8. 공지사항 시퀀스
create sequence noticeSeq;

--================== [2단계] ===================================


-- 9. 대관문의 테이블
create table tblRent(

 postSeq number primary key,                      -- 게시글번호(PK)
 userSeq number references tblUser (userSeq),    -- 회원번호(FK)
 theaterName VARCHAR2(30) not null,              -- 극장이름
rentDate date not null,	                             -- 대관희망일
movieName VARCHAR2(50) not null,                  -- 영화이름
rentPeople number not null,		                     -- 관람인원
rentTitle VARCHAR2(100) not null,	                 -- 글제목
rentContent VARCHAR2(2000) not null,             -- 글내용	
rentRegdate DATE not null,		                     -- 등록일
rentCommentCheck VARCHAR2(1) default 'N'        -- 답변처리여부
);



-- 9.  대관문의 시퀀스
create sequence postSeq;
--=====================================================

-- 10. 1:1 문의 테이블
create table tblPersonal(

 personalSeq number primary key,                  -- 게시글 번호(PK)
 userSeq number references tblUser (userSeq),    -- 회원번호(FK)
 theaterName VARCHAR2(50) not null,              -- 극장이름
 personalType VARCHAR2(30)  not null, 	         -- 문의유형
 personalTitle  VARCHAR2(100) not null,            -- 글제목
 personalContent VARCHAR2(2000) not null,        -- 글 내용
 personalPicture VARCHAR2(100) not null,           -- 사진첨부이름
 personalRegdate DATE not null,                     -- 등록일
 personalCommentCheck VARCHAR2(1) default 'N'   -- 답변처리여부
);

-- 10. 1:1문의 시퀀스
create sequence personalSeq;
--=====================================================

-- 11. 분실물 문의 테이블
create table tblLost ( 
 PostSeq number primary key ,                            -- 게시글번호(PK)
 userSeq  number references tblUser (userSeq),          -- 회원번호(FK)
 theaterName  VARCHAR2(50) not null,                    -- 극장이름
 lostTitle VARCHAR2(100) not null,                         -- 글제목
 lostContent VARCHAR2(2000) not null,                    -- 글내용
 lostDate DATE not null,		                                -- 등록일
 lostStatus VARCHAR2(20) not null,                        -- 접수상태
 lostPw VARCHAR2(50) not null,	                            -- 비밀번호
 lostCommentCheck VARCHAR2(1) default 'N'               -- 답변처리여부
);

-- 11. 분실물 문의 시퀀스
create sequence PostSeq;
--=====================================================


-- 12. 매점 테이블

create table tblStore(
    
    itemSeq number primary key,                -- 제품번호(PK)
    itemName varchar2(50) not null,             -- 제품명
    itemPrice number not null,                    -- 가격
    itemCount number not null,                   -- 제품 수량
    itemClass varchar2(30) not null,              -- 제품 분류(팝콘/음료/티켓/세트)
    itemImage varchar2(100) not null,            -- 제품 이미지
    theaterSeq number not null references tblTheater (theaterSeq)  -- 극장번호(FK)

);

-- 12. 매점 시퀀스
create sequence itemSeq;

--================ [ 3단계 ] =============================



-- 13. 이벤트 댓글 테이블
create table tblEventReply (

 eventSeq number not null references tblEvent (eventSeq),    -- 이벤트 번호
 eventComment VARCHAR2(500) not null,                          -- 댓글 내용
 eventCommentRegdate DATE not null,                             -- 등록일
 userSeq  number  not null	 	                                    -- 회원번호
);

-- 13. 이벤트 댓글 시퀀스

--=======================================================================









-- 14. 매점 구매내역 테이블
create table tblStoreHistory(

 storeHistorySeq number primary key ,                                -- 매점구매내역번호(PK)
 itemSeq number not null references tblStore (itemSeq),            -- 제품번호(FK)
 userSeq number not null references tblUser (userSeq), 	            -- 회원번호
 storeHistoryRegdate date not null,	                                -- 구매날짜
 storeHistoryCount number not null,	                                -- 구매수량
 storeCheck VARCHAR2(1) default 'N' 	                                 -- 제품사용여부
);

-- 14. 매점 구매내역 시퀀스
create sequence storeHistorySeq;
--===================================================




-- 15. 영화스케쥴 테이블
create table tblSchedule(

 scheduleSeq number primary key,                                        -- 상영영화번호(PK)
 scheduleDate date not null ,                                                -- 상영날짜
 scheduleTime date not null,                                                 -- 상영시간
 theaterRoomName varchar2(10) not null,		                             -- 상영관번호
 theaterSeq number not null references tblTheater (theaterSeq) ,     -- 극장번호(FK)
 movieSeq number not null references tblMovie(movieSeq)              --영화번호(FK)
);


-- 15. 영화스케쥴 시퀀스(상영영화번호)
create sequence scheduleSeq;
--===================================================

-- 16. 영화댓글 테이블
create table tblMovieComment(

 movieCommentSeq number primary key,                        -- 영화댓글번호(PK)
 userSeq number not null references tblUser (userSeq),      -- 회원번호(FK)
 movieSeq number not null references tblMovie(movieSeq),   -- 영화번호(FK)
 movieCommentRegdate date not null,                           -- 작성일
 movieCommentContent varchar2(500) not null,                -- 내용
 movieScore number not null                                     -- 평점

);

-- 16. 영화댓글 시퀀스
create sequence movieCommentSeq;
--===================================================

-- 17. 예매 테이블
create table tblTicketing(

 ticketingSeq NUMBER primary key ,                                         -- 예매번호(PK)
 userSeq number not null references tblUser (userSeq),                   -- 회원번호(FK),
 ticketingMovie number not null references tblSchedule (tblSchedule),   -- 상영영화번호(FK)
 ticketingSeat number  not null,                                             -- 좌석번호
 ticketingDate date not null,	                                              -- 예매날짜
 ticketingAdult number default 0,                                            -- 성인
 ticketingTeenager number default 0,                                        -- 청소년
 ticketingkid number default 0                                                -- 어린이

);

-- 17. 예매 시퀀스
create sequence ticketingSeq;
--===================================================

-- 18. 선물내역 테이블
create table tblPresent(

 presentSeq number primary key,		                       -- 선물내역번호(PK)
 userSeq number not null references tblUser (userSeq),    -- 회원번호(FK)
 receiverTel varchar2(15)   not null,		                    -- 수신자전화번호
itemSeq number not null references tblStore (itemSeq),     -- 제품번호(FK)
 presentRegdate date not null, 		                        -- 선물 보낸 날짜
 presentCount number not null, 		                         -- 선물 보낸 수량
 presentCheck varchar2(1) default 'N'		                     -- 선물 사용 여부
);

-- 18. 선물내역 시퀀스
create sequence presentSeq;
--===================================================

-- 19. 쿠폰보유 테이블
create table tblCouponHave (

couponHaveSeq number primary key ,                                 -- 쿠폰보유번호(PK) 
userSeq number not null references tblUser (userSeq),             -- 회원번호(FK)			
couponSeq number not null references tblCoupon (couponSeq)     -- 쿠폰번호(FK)
);


-- 19. 쿠폰보유 시퀀스
create sequence couponHaveSeq;
--===================================================

-- 20. 쿠폰 사용상태 테이블
create table tblCouponStatus(

 couponstatusSeq number primary key,                                -- 쿠폰상태번호(PK)
 couponUseDate date not null,                                          -- 쿠폰사용일
 couponHaveSeq number references tblCouponHave(couponHaveSeq)  -- 쿠폰보유번호(PK)

);

-- 20. 쿠폰 사용상태 시퀀스
create sequence couponstatusSeq;
--===================================================

-- 21. 비회원 예매 테이블
create tabel tblNonUserTicketing(

 ticketingSeq number primary key ,                                   -- 예매번호(PK)
 nonuserSeq number not null references tblNonUser(nonuserSeq),  -- 비회원번호(FK)
 scheduleSeq number not null references tblSchedule (tblSchedule), -- 상영영화번호(FK)
 ticketingSeat number not null,                                         -- 좌석번호 
 ticketingDate date not null,                                            -- 예매날짜
 ticketingAdult number default 0 ,                                      -- 성인
 ticketingTeenager number default 0,                                   -- 청소년 
 ticketingKid number default 0                                           -- 어린이

);

-- 21. 비회원 예매 시퀀스

--커밋
commit;


