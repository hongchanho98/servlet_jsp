-- tblNonUser
drop table tblNonUser;
drop sequence seqNonuser;

-- 테이블 생성
create table tblNonUser(
    nonuserSeq number primary key,          -- 비회원번호(PK)
    nonuserName varchar2(20) not null,      -- 이름
    nonuserBirth date not null,             -- 생년월일
    nonuserPw varchar2(20) not null,        -- 비밀번호
    nonuserTel varchar2(15) not null        -- 전화번호
);

create sequence seqNonuser;

-- 데이터 입력
insert into tblNonUser values (seqNonuser.nextVal, '홍서윤', '1964-07-22', 'faze', '010-4877-2582');
insert into tblNonUser values (seqNonuser.nextVal, '장하준', '1986-08-15', 'qdpo', '010-1214-1293');
insert into tblNonUser values (seqNonuser.nextVal, '장민서', '1988-06-20', 'suzg', '010-6281-4155');
insert into tblNonUser values (seqNonuser.nextVal, '서서진', '1980-08-03', 'eark', '010-8163-8408');
insert into tblNonUser values (seqNonuser.nextVal, '신유니', '1965-10-12', 'esfc', '010-3498-8296');
insert into tblNonUser values (seqNonuser.nextVal, '김지호', '1963-12-25', 'biuc', '010-7171-3312');
insert into tblNonUser values (seqNonuser.nextVal, '박서진', '1990-03-29', 'gmhg', '010-1149-8190');
insert into tblNonUser values (seqNonuser.nextVal, '차은우', '1999-12-12', 'sehi', '010-2120-7151');
insert into tblNonUser values (seqNonuser.nextVal, '임서준', '1964-02-14', 'lkhs', '010-9559-9304');
insert into tblNonUser values (seqNonuser.nextVal, '최수아', '1983-09-22', 'lqim', '010-8746-2124');
insert into tblNonUser values (seqNonuser.nextVal, '박서윤', '1974-05-11', 'bzmj', '010-5921-3702');
insert into tblNonUser values (seqNonuser.nextVal, '서서윤', '1980-10-18', 'jknq', '010-6290-5530');
insert into tblNonUser values (seqNonuser.nextVal, '고지호', '1998-02-10', 'nzkq', '010-9739-5590');
insert into tblNonUser values (seqNonuser.nextVal, '손민준', '1977-09-24', 'iwkw', '010-8410-7983');
insert into tblNonUser values (seqNonuser.nextVal, '정지아', '1980-10-23', 'oosk', '010-2601-9050');
insert into tblNonUser values (seqNonuser.nextVal, '신유니', '1998-11-03', 'nbnr', '010-4327-7546');
insert into tblNonUser values (seqNonuser.nextVal, '조지호', '1984-02-21', 'cjan', '010-7546-7040');
insert into tblNonUser values (seqNonuser.nextVal, '손건우', '1978-02-28', 'wjam', '010-6632-8539');
insert into tblNonUser values (seqNonuser.nextVal, '손유니', '1964-10-28', 'qchd', '010-7524-2044');
insert into tblNonUser values (seqNonuser.nextVal, '홍지호', '1960-05-19', 'pzwz', '010-3117-9237');

commit;

select * from tblNonUser;