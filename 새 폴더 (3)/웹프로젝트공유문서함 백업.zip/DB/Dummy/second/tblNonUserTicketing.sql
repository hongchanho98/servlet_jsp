create table tblNonUserTicketing(
	
	ticketingSeq number primary key,		-- 예매번호
	nonuserSeq number not null,		-- 비회원번호
	scheduleSeq number not null,		-- 영화번호	
	ticketingDate date not null,			-- 예매날짜 
	
);


--모가디슈, 영화번호 : 1, 2021-07-28

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,61,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,63,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,80,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,5,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,36,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,78,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,61,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,37,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,37,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,44,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,10,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,61,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,17,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,96,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,89,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,55,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,23,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,29,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,36,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,61,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,1,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,80,1,'2021-07-25');



--블랙위도우, 영화번호 : 2, 2021-07-07

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,23,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,92,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,21,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,60,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,8,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,92,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,21,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,44,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,9,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,33,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,78,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,4,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,2,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,2,'2021-07-25');


--블랙위도우, 영화번호 : 3, 2021-07-07

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,5,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,89,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,10,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,9,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,60,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,29,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,63,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,96,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,44,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,89,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,80,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,8,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,37,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,89,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,37,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,23,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,56,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,96,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,55,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,29,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,36,3,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,3,'2021-07-26');



--이스케이프 룸 2: 노 웨이 아웃, 영화번호 : 4, 2021-07-14

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,29,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,22,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,23,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,22,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,47,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,36,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,37,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,4,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,22,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,8,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,29,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,60,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,17,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,4,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,4,'2021-07-27');


--랑종, 영화번호 : 5, 2021-07-14

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,22,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,27,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,9,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,80,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,22,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,80,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,33,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,92,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,37,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,5,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,61,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,29,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,36,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,92,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,44,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,89,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,22,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,5,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,10,5,'2021-07-28');


-- 크루엘라, 영화번호 : 6, 2021-05-26
insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,22,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,27,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,80,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,55,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,23,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,9,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,33,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,60,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,10,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,36,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,17,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,37,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,21,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,22,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,44,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,80,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,5,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,47,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,56,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,96,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,23,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,6,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,4,6,'2021-07-25');

-- 발신제한, 영화번호 : 7, 2021-06-23
insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,44,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,80,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,63,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,61,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,17,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,56,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,78,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,10,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,56,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,27,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,53,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,33,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,21,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,53,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,63,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,47,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,21,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,47,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,92,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,53,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,47,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,7,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,89,7,'2021-07-28');


-- 루카, 영화번호 : 8, 2021-06-17

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,9,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,37,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,37,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,17,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,5,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,33,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,78,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,36,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,96,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,9,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,22,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,27,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,8,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,55,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,10,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,96,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,8,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,8,'2021-07-31');

--콰이어트 플레이스 2 , 영화번호 : 9 ,2021-06-16
insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,92,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,96,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,17,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,23,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,33,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,53,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,80,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,36,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,56,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,89,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,56,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,4,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,10,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,29,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,27,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,29,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,27,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,44,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,21,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,9,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,9,'2021-07-25');


--이도공간, 영화번호 : 10 , 2021-07-21

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,47,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,47,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,29,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,29,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,5,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,60,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,44,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,89,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,47,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,17,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,33,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,53,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,23,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,36,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,47,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,96,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,23,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,22,10,'2021-07-26');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,96,10,'2021-07-26');

-- 트립 투 그리스, 영화번호 : 11, 2021-07-08

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,4,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,22,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,27,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,80,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,44,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,61,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,21,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,78,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,96,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,9,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,44,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,29,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,22,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,55,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,21,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,78,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,27,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,21,11,'2021-07-27');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,11,'2021-07-27');

-- 라라랜드(2016) ,영화번호 : 12, 2021-07-25
insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,23,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,37,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,78,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,47,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,29,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,4,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,4,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,80,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,55,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,17,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,56,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,80,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,61,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,53,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,12,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,12,'2021-07-28');


--나의 소녀시대(2016), 영화번호 : 13 , '2021-07-25'

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,56,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,5,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,63,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,96,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,10,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,27,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,63,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,4,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,17,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,23,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,27,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,9,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,80,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,8,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,37,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,78,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,10,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,5,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,13,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,96,13,'2021-07-29');



--소울,영화번호 : 14 ,'2021-07-24'

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,60,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,5,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,61,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,92,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,36,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,53,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,37,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,80,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,61,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,36,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,89,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,44,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,27,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,92,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,9,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,36,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,8,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,78,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,23,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,89,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,63,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,92,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,17,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,37,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,5,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,78,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,60,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,55,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,17,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,22,14,'2021-07-30');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,14,'2021-07-30');




-- 영화번호 15번

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,61,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,8,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,44,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,5,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,29,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,9,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,96,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,27,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,10,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,92,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,37,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,44,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,56,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,10,15,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,15,'2021-07-31');

-- 영화번호 16번

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,4,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,22,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,44,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,56,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,61,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,53,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,47,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,47,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,55,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,17,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,27,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,17,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,92,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,53,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,8,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,53,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,36,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,44,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,36,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,16,'2021-07-28');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,16,'2021-07-28');


-- 영화번호 17번

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,8,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,60,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,96,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,55,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,4,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,53,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,92,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,4,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,53,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,37,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,53,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,96,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,29,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,10,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,9,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,10,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,92,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,89,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,53,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,44,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,37,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,47,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,17,'2021-07-31');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,17,'2021-07-31');


-- 영화번호 18번

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,5,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,27,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,39,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,55,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,33,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,64,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,40,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,69,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,76,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,61,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,8,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,19,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,36,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,63,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,56,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,63,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,22,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,25,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,47,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,63,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,8,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,17,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,89,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,82,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,9,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,8,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,32,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,17,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,47,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,78,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,33,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,8,18,'2021-07-29');



-- 영화번호 19번


insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,9,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,45,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,21,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,89,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,56,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,83,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,42,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,4,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,75,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,3,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,5,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,22,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,53,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,89,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,10,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,17,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,34,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,13,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,70,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,57,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,9,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,78,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,9,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,49,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,21,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,47,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,15,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,54,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,1,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,71,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,92,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,96,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,68,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,94,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,41,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,17,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,56,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,99,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,16,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,78,18,'2021-07-29');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,18,'2021-07-29');

-- 영화번호 20번

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,95,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,21,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,27,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,79,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,28,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,88,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,9,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,43,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,59,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,55,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,37,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,51,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,77,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,55,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,47,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,48,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,65,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,58,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,53,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,6,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,8,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,8,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,20,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,80,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,63,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,85,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,73,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,35,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,30,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,27,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,74,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,56,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,26,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,67,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,21,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,46,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,31,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,29,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,93,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,80,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,12,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,90,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,84,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,91,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,4,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,52,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,87,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,18,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,7,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,63,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,86,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,4,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,14,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,98,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,62,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,89,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,50,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,38,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,11,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,66,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,72,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,2,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,81,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,24,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,9,20,'2021-07-25');

insert into tblNonUserTicketing (ticketingSeq,nonuserSeq,scheduleSeq,ticketingDate) values (seqTicketing.nextVal,97,20,'2021-07-25');



