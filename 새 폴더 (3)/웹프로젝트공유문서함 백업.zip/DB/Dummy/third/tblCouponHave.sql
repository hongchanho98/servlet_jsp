-- 쿠폰 보유 테이블
-- drop table tblCouponHave;
-- drop sequence couponHaveSeq;

create table tblCouponHave (

    couponHaveSeq number primary key ,                                 -- 쿠폰보유번호(PK) 
    userSeq number not null references tblUser (userSeq),             -- 회원번호(FK)			
    couponSeq number not null references tblCoupon (couponSeq)     -- 쿠폰번호(FK)

);

create sequence couponHaveSeq;


-- 더미데이터( 회원 50명에게 쿠폰)
insert into tblCouponHave values(couponHaveSeq.nextVal, 82, 2 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 87, 5 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 19, 4 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 81, 4 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 9, 5 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 26, 4 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 29, 4 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 80, 4 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 88, 5 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 23, 4 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 54, 1 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 72, 2 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 37, 3 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 86, 1 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 31, 6 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 34, 2 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 34, 3 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 55, 6 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 56, 1 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 26, 4 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 100, 2 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 35, 4 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 59, 3 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 86, 1 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 15, 1 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 58, 2 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 1, 2 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 14, 1 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 37, 3 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 49, 3 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 11, 6 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 65, 4 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 60, 2 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 100, 6 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 96, 6 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 66, 5 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 93, 3 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 46, 6 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 86, 2 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 94, 4 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 93, 4 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 31, 5 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 12, 2 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 88, 3 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 66, 1 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 20, 3 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 3, 1 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 28, 3 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 72, 1 );
insert into tblCouponHave values(couponHaveSeq.nextVal, 65, 5 );

--커밋
commit;
